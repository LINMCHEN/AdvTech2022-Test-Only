# from gym import envs
# import tunnel
#
# envids = [spec.id for spec in envs.registry.values()]
# for envid in sorted(envids):
#     print(envid)

import numpy as np

file = np.load('D:/pythonProject/python_project/LegibleMDP/q/0_0.9.npy')
print(file)
np.savetxt('D:/pythonProject/python_project/LegibleMDP/q/0_0.9.txt',file)
